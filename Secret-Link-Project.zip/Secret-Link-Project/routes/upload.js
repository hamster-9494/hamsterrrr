const express = require('express');
const multer = require('multer');
const path = require('path');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const File = require('../models/File');

const router = express.Router();

// 파일 저장 방식 설정 (안전한 이름 사용)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname); // 예: .hwp
    const safeName = `${Date.now()}-${uuidv4()}${ext}`;
    cb(null, safeName);
  }
});

const upload = multer({ storage });

// 업로드 API
router.post('/upload', upload.single('file'), async (req, res) => {
  const { password, expireMinutes, downloadLimit } = req.body;

  // 비밀번호 필수 확인
  if (!password) {
    return res.status(400).json({ error: '비밀번호는 필수 입력 항목입니다.' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const file = new File({
    originalName: req.file.originalname,   // 사용자에게 보여줄 원래 이름
    path: req.file.path,                   // 실제 저장 경로 (UUID 기반 이름)
    linkId: uuidv4(),                      // 다운로드 링크 식별용 ID
    password: hashedPassword,
    expireAt: new Date(Date.now() + (expireMinutes || 60) * 60000),
    downloadLimit: downloadLimit || 1,
    downloads: 0
  });

  await file.save();

  res.json({ downloadLink: `/download/${file.linkId}` });
});

module.exports = router;
