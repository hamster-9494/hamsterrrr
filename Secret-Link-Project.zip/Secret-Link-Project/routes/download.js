const express = require('express');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const File = require('../models/File');

const router = express.Router();

// 비밀번호 입력 폼 보여주기
router.get('/download/:id', async (req, res) => {
  const { id } = req.params;
  const file = await File.findOne({ linkId: id });

  if (!file) {
    return res.status(404).send('링크가 존재하지 않습니다.');
  }

  if (file.expireAt < new Date()) {
    return res.status(410).send('링크가 만료되었습니다.');
  }

  // 무조건 비밀번호 입력 폼으로 이동
  res.sendFile(path.join(__dirname, '../public/password-form.html'));
});

// 비밀번호 입력 후 다운로드 처리
router.post('/download/:id', async (req, res) => {
  const { id } = req.params;
  const { password } = req.body;

  try {
    const file = await File.findOne({ linkId: id });

    if (!file) {
      return res.status(404).send('링크가 존재하지 않습니다.');
    }

    if (file.expireAt < new Date()) {
      return res.status(410).send('링크가 만료되었습니다.');
    }

    const isMatch = await bcrypt.compare(password || '', file.password);
    if (!isMatch) {
      return res.status(401).send('비밀번호가 일치하지 않습니다.');
    }

    if (file.downloads >= file.downloadLimit) {
      return res.status(403).send('다운로드 제한을 초과했습니다.');
    }

    const filePath = path.resolve(file.path);

    if (!fs.existsSync(filePath)) {
      return res.status(410).send('파일이 존재하지 않습니다.');
    }

    file.downloads += 1;

    if (file.downloads >= file.downloadLimit) {
      await File.deleteOne({ _id: file._id });
      fs.unlinkSync(filePath);
    } else {
      await file.save();
    }

    res.download(filePath, file.originalName);

  } catch (err) {
    console.error('다운로드 오류:', err.message);
    res.status(500).send('서버 오류');
  }
});

module.exports = router;
