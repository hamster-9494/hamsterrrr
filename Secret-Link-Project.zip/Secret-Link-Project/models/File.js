const mongoose = require('mongoose');

const fileSchema = new mongoose.Schema({
  originalName: String,
  savedName: String,
  path: String,
  size: Number,
  password: String,           // 비밀번호 (해시 형태로 저장)
  expireAt: Date,             // 유효시간
  downloadLimit: {
    type: Number,
    default: 1                // 기본 다운로드 1회로 설정
  },
  downloads: {
    type: Number,
    default: 0                // 다운로드 횟수 기록용
  },
  linkId: String,             // 고유 링크 ID
  uploadDate: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('File', fileSchema);
